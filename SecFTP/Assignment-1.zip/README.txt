
	Roll no : 201150844
	Name	: Trivedi Ravi Maheshbhai

	
 == > Compilation steps

	gcc -o <exe> <file.c> -lm

 ==> Execution steps

	Server : ./server

		 Choose option : 
 		 New user registration : 1  --> Go to offline user registration
 		 Start Server : 2           --> Start Server normal operation 
 		 Enter option here :

	Client : ./client <serverip> <userid> <password> <filename>
		
		e.g > ./client 127.0.0.1 ravi 1234567890 ftppasswd
		
